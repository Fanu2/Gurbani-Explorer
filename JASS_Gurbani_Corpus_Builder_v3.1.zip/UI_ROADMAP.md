# JASS Gurbani Corpus Builder — UI / Engineering Roadmap

## v3.1 — Structural Reconstruction

Completed direction:

- non-destructive import
- stronger source-noise detection
- explicit classification roles
- review queue
- cohesive passage context
- structure inspector
- validation
- SQLite passages + lines + FTS5
- JSON / CSV export

## v3.2 — Parser Confidence

Add confidence indicators to structural fields:

```text
Ang       930       99%
Raag      Raamkalee 92%
Author    Mahalla 1 88%
Passage   P00421   76%
```

Low-confidence records should automatically enter the Review Queue.

## v3.3 — Manual Structure Editor

A future editor should allow the user to:

- merge passages
- split passages
- assign Ang
- assign Raag
- assign Mahalla
- assign author
- assign stanza number
- rename structural labels
- save corrections as a separate correction layer

The original source must remain unchanged.

## v3.4 — Search Workbench

A dedicated search interface should support:

- exact search
- contains search
- normalized search
- context size
- whole passage
- Ang filter
- Raag filter
- author filter
- result export

## v3.5 — Corpus Health

Visual dashboard:

```text
CORPUS HEALTH

Clean records       ████████████████  92%
Review queue        ██                4%
Duplicates          █                  2%
Other/noise         █                  2%

Structural confidence: 84%
```

## v4.0 — Multi-source Research Corpus

Support multiple editions while retaining provenance:

```text
Corpus
 ├── Source A
 ├── Source B
 └── Source C
       ↓
 Comparison
       ↓
 Verified / Variant / Uncertain
```

The UI should make it clear which text came from which source.

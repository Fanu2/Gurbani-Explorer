# JASS Gurbani Corpus Builder v3.1

## Structural Reconstruction Edition

JASS Gurbani Corpus Builder is a Windows-friendly PySide6 desktop tool for turning a large Gurbani TXT source into a **clean, searchable, auditable corpus** and ultimately a reusable `gurbani.db` database.

This release builds on the cleaned TXT workflow and concentrates on the next important problem: **preserving context and structure instead of treating every matching line as an isolated quotation.**

> **Important:** the application does not claim to perform scholarly or canonical reconstruction automatically. Its structural groups are conservative source-context groupings intended to make search results cohesive. Verify metadata against a trusted source before scholarly publication.

---

## What v3.1 does

### Import

- Opens UTF-8 Gurbani TXT files.
- Preserves original source line numbers.
- Keeps the source file untouched.
- Handles UTF-8 BOM and reports replacement-character problems.

### Cleaning / classification

Records are classified rather than blindly deleted:

- `GURBANI`
- `ANG_MARKER`
- `RAAG_MARKER`
- `AUTHOR_MARKER`
- `STANZA_MARKER`
- `NUMBERING`
- `REFERENCE`
- `NOISE`
- `FRAGMENT`
- `OTHER`
- `DUPLICATE`

This is especially useful when a downloaded source contains Internet Archive, web-page, navigation, URL, or metadata material.

### Review Queue

Potentially uncertain material is retained for inspection.

Double-clicking a review record toggles its inclusion state. This makes it possible to manually promote or exclude questionable fragments without editing the original TXT.

### Context-aware search

Search results retain their passage identifier. Selecting a result displays surrounding records from the same detected source-context passage whenever possible.

This is designed to address the earlier Explorer problem where a search result could begin midway through a passage or end abruptly.

### Structure Inspector

The application displays:

- Ang
- Raag
- Author
- Passage ID
- Stanza number
- Number of lines in the passage
- Source text

The word **Passage** is intentional: v3.1 does not pretend that a simple TXT parser can always determine canonical Shabad boundaries.

### SQLite database

The generated `gurbani.db` contains separate layers:

```text
corpus_meta
source_records
passages
lines
gurbani_fts
```

The important distinction is between:

- **source_records** — the audit trail
- **lines** — clean searchable Gurbani records
- **passages** — cohesive source-context groups
- **gurbani_fts** — full-text search index

This gives the future JASS Gurbani Explorer a much stronger foundation than a flat line-only database.

---

## Recommended workflow

```text
Original TXT
     │
     ▼
Open TXT
     │
     ▼
Import / Rebuild
     │
     ▼
Classification
     │
     ├── Gurbani
     ├── Structural markers
     ├── References
     ├── Noise
     ├── Fragments
     └── Duplicates
     │
     ▼
Review Queue
     │
     ▼
Validation
     │
     ▼
Build gurbani.db
     │
     ▼
JASS Gurbani Explorer
```

---

## Why the original TXT is not modified

The corpus builder follows a **non-destructive workflow**.

Do not clean the source by repeatedly editing the TXT itself. Instead:

```text
SOURCE
  ↓
CLASSIFICATION
  ↓
REVIEW
  ↓
CLEAN CORPUS
```

Every source record keeps its original source line number and text in the database audit table.

This means a questionable removal can be investigated later.

---

## Database structure

### `corpus_meta`

Stores builder version, source file, encoding and corpus statistics.

### `source_records`

The audit trail for imported records.

Important fields include:

```text
source_line
kind
included
duplicate
review_status
text
```

### `passages`

A cohesive source-context grouping.

```text
id
ang
raag
author
section
text
line_count
```

### `lines`

The searchable clean corpus.

```text
id
passage_id
source_line
ang
raag
author
stanza_no
text
normalized_text
text_hash
```

### `gurbani_fts`

SQLite FTS5 search index over the clean lines.

---

## Running on Windows

A separate virtual environment is **not required** if PySide6 is already installed globally, which is the intended setup for this project.

From PowerShell:

```powershell
cd "C:\Users\singh\Downloads\JASS_Gurbani_Corpus_Builder_v3.1"
py .\JASS_Gurbani_Corpus_Builder_v3.1.py
```

If PowerShell complains that the script name is not recognized, use `.` before the filename as shown above.

Check PySide6 if necessary:

```powershell
py -c "import PySide6; print(PySide6.__version__)"
```

---

## Current limitations

The following are deliberately **not** claimed as solved automatically in v3.1:

- perfect canonical Shabad boundaries
- perfect Ang parsing from every possible source format
- perfect Raag/Mahalla recognition
- authoritative author attribution
- perfect stanza segmentation
- scholarly validation against every published edition

The program is a **corpus engineering and preparation tool**, not a replacement for source verification.

---

# Future roadmap

## v3.2 — Stronger structural parser

Planned:

- better Ang boundary detection
- explicit Mahalla parsing
- improved Raag extraction
- author normalization
- canonical marker recognition
- better stanza/Pauri detection
- structural confidence scores

## v3.3 — Shabad reconstruction

Planned database relationships:

```text
Ang
 └── Raag
      └── Mahalla / Author
           └── Shabad
                ├── Stanza / Pauri
                │    ├── Line
                │    ├── Line
                │    └── Line
                └── Complete Text
```

## v3.4 — Advanced search

Possible search modes:

- exact phrase
- word search
- normalized search
- Ang search
- Raag search
- author search
- passage search
- context expansion
- whole-Shabad results

## v3.5 — Corpus quality dashboard

Possible metrics:

- clean percentage
- duplicate percentage
- unresolved records
- structural confidence
- missing Angs
- suspicious gaps
- passage statistics
- search coverage

## v4.0 — Research Corpus Edition

Potential features:

- multiple source editions
- source comparison
- variant-text detection
- provenance tracking
- manual structural editing
- import/export of corrections
- corpus snapshots
- database migrations
- reproducible builds

---

# Relationship to JASS Gurbani Explorer

The long-term goal is to make `gurbani.db` a reusable foundation rather than a database created only for the Corpus Builder.

The same database can support:

- JASS Gurbani Explorer
- contextual search
- Random Gurbani
- Favorites
- quotation extraction
- Card Studio
- research tools
- future desktop applications

The desired search experience is:

```text
SEARCH
  ↓
MATCHING LINE
  ↓
COMPLETE PASSAGE
  ↓
SHABAD / STRUCTURAL CONTEXT
  ↓
ANG • RAAG • AUTHOR
```

rather than:

```text
SEARCH
  ↓
ONE ISOLATED LINE
```

---

## Design principle

**Preserve first. Classify second. Review third. Structure fourth. Export last.**

That principle should keep the corpus recoverable while we progressively improve the parser.

---

## Version

**JASS Gurbani Corpus Builder v3.1 — Structural Reconstruction Edition**

The cleaned TXT used as the current source baseline should be preserved separately from generated databases and exports.

# JASS Gurbani Corpus Builder v4.7

## Purpose

v4.7 continues the verified Shabad OS -> JASS database workflow.

The key addition is an **exact Asset Link investigation** for the relationship:

```text
asset_lines.line_id -> lines.id
```

The source `master.sqlite` is opened read-only and is never modified.

## Why v4.7

The generic text investigation can report:

```text
asset_lines.data = 100% Gurmukhi
line-ID overlap = 0%
```

That does not necessarily mean the asset is unrelated. It means the generic sampled-column heuristic is not the correct tool for proving this particular relationship.

v4.7 therefore adds an exact database-level investigation that directly joins `asset_lines.line_id` to `lines.id`.

## Asset Link investigation

The new **Asset Link** button/tab reports exact counts for:

- total `asset_lines` rows
- `type='primary'` rows
- primary rows containing non-empty `data`
- primary text rows joined to `lines`
- distinct `lines.id` reached by primary text
- total `lines` rows
- lines without a primary text link
- primary `asset_id` distribution
- real joined Gurmukhi samples
- primary text coverage percentage

This is not based on a 5,000-row heuristic sample.

## Verified source relationship

The inspected release is expected to expose the authoritative text path as:

```text
asset_lines.type = 'primary'
asset_lines.line_id = lines.id
asset_lines.data = Gurmukhi text
```

The exact Asset Link investigation should be run against the user's actual `master.sqlite` before treating this relationship as verified for that release.

## SGGS scope

Sri Guru Granth Sahib membership remains a separate structural question. It is not inferred from the presence of Gurmukhi text.

The builder uses:

```text
lines.line_group_id
        -> line_groups.id
        -> line_groups.section_id
        -> sections.id
        -> sections.source_id = 'SGGS'
```

Only groups established through this relationship are imported when the scope is **Sri Guru Granth Sahib — auto-detect**.

## Build architecture

```text
master.sqlite
     |
     | read-only
     v
Schema analysis
     |
     v
Exact asset relationship investigation
     |
     v
Verified Gurmukhi text
     |
     v
Verified SGGS structural scope
     |
     v
JASS_Gurbani.db
     |
     +--> JASS Gurbani Explorer
     +--> deterministic search
     +--> passage reader
     +--> cards/study tools
     +--> optional chunking
     +--> optional embeddings / RAG
```

The canonical database is **not** replaced by chunks or embeddings. Those belong to a later search/AI layer.

## Safety rules

- `master.sqlite` is opened read-only.
- The source database is never modified.
- A separate `JASS_Gurbani.db` is created.
- Original source IDs are preserved.
- Source provenance is recorded.
- No silent transliteration or correction is performed.
- Empty/zero-line imports are not considered successful corpus builds.
- SGGS scope is not guessed from Gurmukhi content alone.

## Run on Windows

From PowerShell:

```powershell
cd C:\Users\singh\Downloads\JASS_Gurbani_Corpus_Importer_v4.7
py -m py_compile .\JASS_Gurbani_Corpus_Importer_v4.7.py
py .\JASS_Gurbani_Corpus_Importer_v4.7.py
```

## Recommended procedure

1. Start v4.7.
2. Open `master.sqlite`.
3. Run **Analyze Schema**.
4. Open **Asset Link** and run the exact relationship investigation.
5. Confirm that primary `asset_lines` records reach the expected `lines.id` population.
6. Review **Investigation** for the text mapping.
7. Confirm the SGGS structural path is available.
8. Click **Build JASS_Gurbani.db**.
9. Click **Validate Built DB**.
10. Open the resulting database in JASS Gurbani Explorer.

## Current checkpoint

**v4.7 — Exact Asset Relationship Investigation**

The project has moved from heuristic text discovery to direct verification of the actual asset-to-line relationship. The next database build should be performed only after the exact Asset Link report confirms the expected coverage in the user's `master.sqlite`.
